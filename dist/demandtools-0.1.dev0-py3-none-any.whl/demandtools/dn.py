import pandas as pd
import numpy as np
import collections
import torch
import torch.nn as nn
import torch.utils.data as utils_data

class NetworkModel(torch.nn.Module):
    def __init__(self, input_node, hl_node, output_node, hl_transformation, bias=True):
        super().__init__()
        if isinstance(hl_node, int):
            hl = 1
        elif isinstance(hl_node, tuple):
            hl = hl_node.__len__()
        else:
            raise TypeError("number_hl_node must be an int or a tuple of integers but it is {}".
                            format(type(hl_node)))

        if isinstance(bias, bool):
            bias_list = np.repeat(bias, hl+1)
        elif isinstance(bias, tuple):
            if all(isinstance(n, bool) for n in bias):
                bias_list = np.array(bias)
            else:
                raise TypeError("bias must be a boolean or a tuple of booleans. None boolean entry detected!!!")

        model = collections.OrderedDict()
        layer = 0
        model['hl'+str(layer+1)] = (nn.Linear(input_node, hl_node, bias=bias_list[0]) if hl == 1 else
                                    nn.Linear(input_node, hl_node[layer], bias=bias_list[layer]))
        model['hl'+str(layer+1)+' transformation'] = hl_transformation
        if hl == 1:
            model['ol'] = nn.Linear(hl_node, output_node, bias_list[hl])
        else:
            while layer < hl-1:
                layer = layer + 1
                model['hl'+str(layer+1)] = nn.Linear(hl_node[layer-1], hl_node[layer], bias=bias_list[layer])
                model['hl'+str(layer+1)+' transformation'] = hl_transformation
                model['ol'] = nn.Linear(hl_node[-1], output_node, bias=bias_list[-1])
            model['ol transformation'] = nn.Softmax(dim=1)
        self.model = nn.Sequential(model)


class DemandDataset(utils_data.Dataset):
    """Designed for a sample with log-prices, log-expenditure, and demographics. All transformation has to be applied
    beforehand. This class reads from an external csv file."""

    def __init__(self, price, expenditure, budget_share, demographics=None):
        self.x = pd.concat([price, expenditure], axis=1)
        if demographics is not None:
            self.x = pd.concat([self.x, demographics], axis=1)
        self.x = torch.tensor(np.array(self.x), dtype=torch.float32)
        self.y = torch.tensor(np.array(budget_share), dtype=torch.float32)

        if len(self.x) != len(self.y):
            raise ValueError("x and y have different numbers of observations.")

    def __len__(self):
        return len(self.x)

    def __getitem__(self, item):
        x = self.x[item, :]
        y = self.y[item, :]
        data = {'x': x, 'y': y}
        return data
